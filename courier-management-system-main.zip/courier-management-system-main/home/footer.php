<!-- copyright and contactUs fixed footer -->

<!DOCTYPE html>
<html>
<head>
<style>
.footer {
    position: fixed;
    width: 100%;
    text-align: center;
    
    bottom: 0;
    background-color: #2ab7ca;
    color: white;
}
</style>
</head>
<body>
<footer class="footer">

  <p style="margin-top: 4px;margin-bottom:-10px">Copyright © 2022 Built by Keerthana MS & Krishna Shekar</p><br>
  <a href="/home/contactUs.php" style="color:white">Contact Us</a>

</footer>

</body>
</html>
